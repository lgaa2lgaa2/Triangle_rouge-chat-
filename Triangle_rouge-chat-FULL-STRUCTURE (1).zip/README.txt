Project Triangle Rouge - placeholders
